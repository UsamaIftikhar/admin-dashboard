import { createContext, useContext, useState, useEffect, ReactNode } from "react";

export interface UserProfile {
  id: string;
  name: string;
  email: string;
  phone: string;
  createdAt: string;
}

export interface SavedAddress {
  id: string;
  label: string;
  firstName: string;
  lastName: string;
  address: string;
  city: string;
  state: string;
  zip: string;
  country: string;
  isDefault: boolean;
}

export interface OrderHistoryItem {
  cartKey: string;
  productId: string;
  name: string;
  artist: string;
  price: number;
  image: string;
  size: string;
  quantity: number;
}

export interface Order {
  id: string;
  items: OrderHistoryItem[];
  subtotal: number;
  shipping: number;
  tax: number;
  total: number;
  status: "Processing" | "Shipped" | "Delivered";
  createdAt: string;
  shippingAddress: Omit<SavedAddress, "id" | "label" | "isDefault">;
}

interface StoredUser extends UserProfile {
  passwordHash: string;
}

interface AuthContextType {
  user: UserProfile | null;
  isLoggedIn: boolean;
  login: (email: string, password: string) => string | null;
  signup: (name: string, email: string, phone: string, password: string) => string | null;
  logout: () => void;
  updateProfile: (data: Partial<Pick<UserProfile, "name" | "phone">>) => void;
  changePassword: (oldPassword: string, newPassword: string) => string | null;
  savedAddresses: SavedAddress[];
  addAddress: (address: Omit<SavedAddress, "id">) => void;
  updateAddress: (id: string, address: Omit<SavedAddress, "id">) => void;
  removeAddress: (id: string) => void;
  setDefaultAddress: (id: string) => void;
  orders: Order[];
  addOrder: (order: Omit<Order, "id" | "createdAt" | "status">) => void;
}

const AuthContext = createContext<AuthContextType | null>(null);

const simpleHash = (str: string) =>
  btoa(encodeURIComponent(str + "1jm_salt_2025")).slice(0, 32);

const uid = () => `u_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`;

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<UserProfile | null>(null);
  const [savedAddresses, setSavedAddresses] = useState<SavedAddress[]>([]);
  const [orders, setOrders] = useState<Order[]>([]);

  useEffect(() => {
    try {
      const storedId = localStorage.getItem("1jm_auth");
      if (storedId) {
        const users: StoredUser[] = JSON.parse(localStorage.getItem("1jm_users") || "[]");
        const found = users.find((u) => u.id === storedId);
        if (found) {
          const { passwordHash: _, ...profile } = found;
          setUser(profile);
          loadUserData(storedId);
        }
      }
    } catch {}
  }, []);

  const loadUserData = (userId: string) => {
    try {
      const addrs = JSON.parse(localStorage.getItem(`1jm_addresses_${userId}`) || "[]");
      setSavedAddresses(addrs);
      const ords = JSON.parse(localStorage.getItem(`1jm_orders_${userId}`) || "[]");
      setOrders(ords);
    } catch {}
  };

  const persistAddresses = (userId: string, addrs: SavedAddress[]) => {
    localStorage.setItem(`1jm_addresses_${userId}`, JSON.stringify(addrs));
  };

  const persistOrders = (userId: string, ords: Order[]) => {
    localStorage.setItem(`1jm_orders_${userId}`, JSON.stringify(ords));
  };

  const login = (email: string, password: string): string | null => {
    try {
      const users: StoredUser[] = JSON.parse(localStorage.getItem("1jm_users") || "[]");
      const found = users.find(
        (u) => u.email.toLowerCase() === email.toLowerCase()
      );
      if (!found) return "No account found with that email.";
      if (found.passwordHash !== simpleHash(password))
        return "Incorrect password.";
      const { passwordHash: _, ...profile } = found;
      setUser(profile);
      localStorage.setItem("1jm_auth", found.id);
      loadUserData(found.id);
      return null;
    } catch {
      return "An error occurred. Please try again.";
    }
  };

  const signup = (
    name: string,
    email: string,
    phone: string,
    password: string
  ): string | null => {
    try {
      const users: StoredUser[] = JSON.parse(localStorage.getItem("1jm_users") || "[]");
      if (users.find((u) => u.email.toLowerCase() === email.toLowerCase()))
        return "An account with this email already exists.";
      const newUser: StoredUser = {
        id: uid(),
        name,
        email,
        phone,
        createdAt: new Date().toISOString(),
        passwordHash: simpleHash(password),
      };
      const updated = [...users, newUser];
      localStorage.setItem("1jm_users", JSON.stringify(updated));
      const { passwordHash: _, ...profile } = newUser;
      setUser(profile);
      localStorage.setItem("1jm_auth", newUser.id);
      setSavedAddresses([]);
      setOrders([]);
      return null;
    } catch {
      return "An error occurred. Please try again.";
    }
  };

  const logout = () => {
    setUser(null);
    setSavedAddresses([]);
    setOrders([]);
    localStorage.removeItem("1jm_auth");
  };

  const updateProfile = (data: Partial<Pick<UserProfile, "name" | "phone">>) => {
    if (!user) return;
    const updated = { ...user, ...data };
    setUser(updated);
    const users: StoredUser[] = JSON.parse(localStorage.getItem("1jm_users") || "[]");
    const next = users.map((u) =>
      u.id === user.id ? { ...u, ...data } : u
    );
    localStorage.setItem("1jm_users", JSON.stringify(next));
  };

  const changePassword = (oldPassword: string, newPassword: string): string | null => {
    if (!user) return "Not logged in.";
    const users: StoredUser[] = JSON.parse(localStorage.getItem("1jm_users") || "[]");
    const found = users.find((u) => u.id === user.id);
    if (!found) return "User not found.";
    if (found.passwordHash !== simpleHash(oldPassword))
      return "Current password is incorrect.";
    const next = users.map((u) =>
      u.id === user.id ? { ...u, passwordHash: simpleHash(newPassword) } : u
    );
    localStorage.setItem("1jm_users", JSON.stringify(next));
    return null;
  };

  const addAddress = (addr: Omit<SavedAddress, "id">) => {
    if (!user) return;
    const newAddr: SavedAddress = { ...addr, id: uid() };
    const updated = addr.isDefault
      ? [...savedAddresses.map((a) => ({ ...a, isDefault: false })), newAddr]
      : [...savedAddresses, newAddr];
    setSavedAddresses(updated);
    persistAddresses(user.id, updated);
  };

  const updateAddress = (id: string, addr: Omit<SavedAddress, "id">) => {
    if (!user) return;
    const updated = savedAddresses.map((a) =>
      a.id === id
        ? { ...addr, id, isDefault: addr.isDefault }
        : addr.isDefault
        ? { ...a, isDefault: false }
        : a
    );
    setSavedAddresses(updated);
    persistAddresses(user.id, updated);
  };

  const removeAddress = (id: string) => {
    if (!user) return;
    const updated = savedAddresses.filter((a) => a.id !== id);
    setSavedAddresses(updated);
    persistAddresses(user.id, updated);
  };

  const setDefaultAddress = (id: string) => {
    if (!user) return;
    const updated = savedAddresses.map((a) => ({
      ...a,
      isDefault: a.id === id,
    }));
    setSavedAddresses(updated);
    persistAddresses(user.id, updated);
  };

  const addOrder = (order: Omit<Order, "id" | "createdAt" | "status">) => {
    if (!user) return;
    const newOrder: Order = {
      ...order,
      id: `1JM-${Math.floor(10000 + Math.random() * 90000)}`,
      createdAt: new Date().toISOString(),
      status: "Processing",
    };
    const updated = [newOrder, ...orders];
    setOrders(updated);
    persistOrders(user.id, updated);
  };

  return (
    <AuthContext.Provider
      value={{
        user,
        isLoggedIn: !!user,
        login,
        signup,
        logout,
        updateProfile,
        changePassword,
        savedAddresses,
        addAddress,
        updateAddress,
        removeAddress,
        setDefaultAddress,
        orders,
        addOrder,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error("useAuth must be used inside AuthProvider");
  return ctx;
}
